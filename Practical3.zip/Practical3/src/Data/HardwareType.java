package Data;

public enum HardwareType {
	CPU, MB, HDD, RAM, GPU, Peripheral
}
